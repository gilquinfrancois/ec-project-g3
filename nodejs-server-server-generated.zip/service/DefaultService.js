'use strict';


/**
 * affiche les détails de la commande demandée
 *
 * commandId Integer id of the command searched
 * returns List
 **/
exports.commandDetailGET = function(commandId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "commandId" : 2,
  "userId" : 4,
  "productId" : 2
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * affiche les détails du produit voulu
 *
 * productId Integer id of the product searched
 * returns List
 **/
exports.productDetailGET = function(productId) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "id" : 2,
  "productName" : "tomate",
  "price" : 0.5,
  "category" : "fruits",
  "description" : "grappe de tomates"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * liste les produits
 *
 * returns List
 **/
exports.productsGET = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "id" : 1,
  "productName" : "pain",
  "price" : 2.5,
  "category" : "feculents",
  "description" : "pain carré blanc"
}, {
  "id" : 2,
  "productName" : "tomate",
  "price" : 0.5,
  "category" : "fruits",
  "description" : "grappe de tomates"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * liste les produits du nom cherché
 *
 * category String category of the product searched
 * returns List
 **/
exports.searchCategoryGET = function(category) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "id" : 2,
  "productName" : "tomate",
  "price" : 0.5,
  "category" : "fruits",
  "description" : "grappe de tomates"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * liste les produits du nom cherché
 *
 * productName String name of the product searched
 * returns List
 **/
exports.searchNameGET = function(productName) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "id" : 2,
  "productName" : "tomate",
  "price" : 0.5,
  "category" : "fruits",
  "description" : "grappe de tomates"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

