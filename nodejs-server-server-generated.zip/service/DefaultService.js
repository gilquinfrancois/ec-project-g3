'use strict';


/**
 * liste les produits
 *
 * returns List
 **/
exports.productsGET = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "id" : 1,
  "productName" : "pain",
  "price" : 2.5,
  "category" : "feculents",
  "description" : "pain carré blanc"
}, {
  "id" : 2,
  "productName" : "tomate",
  "price" : 0.5,
  "category" : "fruits",
  "description" : "grappe de tomates"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * liste les produits du nom cherché
 *
 * search String name of the product searched
 * returns List
 **/
exports.searchGET = function(search) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "id" : 2,
  "productName" : "tomate",
  "price" : 0.5,
  "category" : "fruits",
  "description" : "grappe de tomates"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

