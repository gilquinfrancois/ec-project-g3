'use strict';

var utils = require('../utils/writer.js');
var Default = require('../service/DefaultService');

module.exports.productsGET = function productsGET (req, res, next) {
  Default.productsGET()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.searchCategoryGET = function searchCategoryGET (req, res, next, category) {
  Default.searchCategoryGET(category)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.searchNameGET = function searchNameGET (req, res, next, productName, category) {
  Default.searchNameGET(productName, category)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
