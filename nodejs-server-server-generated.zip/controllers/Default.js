'use strict';

var utils = require('../utils/writer.js');
var Default = require('../service/DefaultService');

module.exports.commandDetailGET = function commandDetailGET (req, res, next, commandId) {
  Default.commandDetailGET(commandId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.productDetailGET = function productDetailGET (req, res, next, productId) {
  Default.productDetailGET(productId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.productsGET = function productsGET (req, res, next) {
  Default.productsGET()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.searchCategoryGET = function searchCategoryGET (req, res, next, category) {
  Default.searchCategoryGET(category)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.searchNameGET = function searchNameGET (req, res, next, productName) {
  Default.searchNameGET(productName)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
